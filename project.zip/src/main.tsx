import { render } from 'solid-js/web';
import App from './App';
import './styles.css';
import './lib/monacoSetup';

const root = document.getElementById('root');
render(() => <App />, root!);

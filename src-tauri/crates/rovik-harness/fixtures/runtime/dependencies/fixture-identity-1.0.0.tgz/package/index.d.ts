export default function identity<T>(value: T): T;
